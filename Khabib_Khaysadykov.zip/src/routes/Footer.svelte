<footer>
    <div id="socials">
        <ul>
            <li><a href="https://github.com/KhaysK/" class="gh-link"><i class="fa-brands fa-github"></i></a></li>
            <li><a href="https://t.me/KhaysK" class="tg-link"><i class="fa-brands fa-telegram"></i></a></li>
            <li><a href="https://www.instagram.com/khabib_khays" class="is-link"><i class="fa-brands fa-instagram"></i></a></li>
            <li><a href="mailto:haysadykov@gmail.com" class="email"><i class="fa-solid fa-envelope"></i></a></li>
        </ul>
    </div>
</footer>

<style>
    footer{
        background-color: #453c38;
        flex-shrink: 0;
    }

    #socials{
        width: 100%;
        display: flex;
        align-items: center;
        padding: 16px 0;
    }

    #socials ul{
        margin: 0;
        width: 100%;
        display: flex;
        justify-content: center;
        list-style-type: none;
    }

    #socials li{
        float: left;
        font-size: 2rem;
        padding-right: 2%;
        
    }
</style>