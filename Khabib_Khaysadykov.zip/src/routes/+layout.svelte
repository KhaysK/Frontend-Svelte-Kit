<script>
	import Footer from "./Footer.svelte";
	import Header from "./Header.svelte";
</script>


<Header/>
<slot />
<Footer/>
